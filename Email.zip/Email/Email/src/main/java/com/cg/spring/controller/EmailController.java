package com.cg.spring.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Merchant;
import com.cg.spring.repo.CouponRepo;
import com.cg.spring.service.EmailService;



@RestController
public class EmailController {

	@Autowired
	private EmailService notificationService;

	@Autowired
	private CouponRepo crepo;
	
	@RequestMapping("/sendcustomer")
	public String sendmailcust(@RequestParam String email)
	{
		Optional<Customer> customer =
		notificationService.getCustomer(Integer.parseInt(email));
		
		System.out.println(customer);
		System.out.println(customer.get().getEmail());
		try
		{
			notificationService.NotificationCustomer(customer);
		}
		catch(MailException e)
		{
			System.out.println(e.getMessage());
		}
		return "Email sent";
	}
	
	@RequestMapping("/sendmerchant")
	public String sendmailmer(@RequestParam String id)
	{
		Optional<Merchant> merchant =
		notificationService.getMerchant(Integer.parseInt(id));
		
		System.out.println(merchant);
		System.out.println(merchant.get().getEmail());
		try
		{
			notificationService.NotificationMerchant(merchant);
		}
		catch(MailException e)
		{
			System.out.println(e.getMessage());
		}
		return "Email sent";
	}
}
