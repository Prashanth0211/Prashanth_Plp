package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Merchant {

	@Id
	@Column(name = "merchant_id")
	private int id;
	@Column(name = "merchant_email")
	private String email;
	@Column(name = "merchant_username")
	private String username;
	@Column(name = "merchant_password")
	private String password;
	public Merchant() {
	}
	public Merchant(int id, String email, String username, String password) {
		super();
		this.id = id;
		this.email = email;
		this.username = username;
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
