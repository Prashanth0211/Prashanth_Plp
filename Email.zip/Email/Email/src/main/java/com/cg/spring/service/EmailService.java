package com.cg.spring.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.Coupons;
import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Merchant;
import com.cg.spring.repo.CouponRepo;
import com.cg.spring.repo.CustomerRepo;
import com.cg.spring.repo.MerchantRepo;

@Service
public class EmailService {

	private JavaMailSender javaMailSender;
	@Autowired
	private CustomerRepo repo;
	@Autowired
	private MerchantRepo mrepo;
	@Autowired
	private CouponRepo crepo;

	
	public EmailService(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	public void NotificationCustomer(Optional<Customer> customer) throws MailException {
		Iterable<Coupons> list = crepo.findAll();
		System.out.println(list.toString());
		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(customer.get().getEmail());
		mail.setFrom("prashanthpsn1995@gmail.com");
		mail.setSubject("Coupons and promos");
		mail.setText("Here are the exciting coupons and promos!!!!!!!!" + list.toString());
		javaMailSender.send(mail);
	}

	public Optional<Customer> getCustomer(int id) {
		return repo.findById(id);
	}
	public void NotificationMerchant(Optional<Merchant> merchant) throws MailException {
		Iterable<Coupons> list = crepo.findAll();
		System.out.println(list.toString());
		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(merchant.get().getEmail());
		mail.setFrom("prashanthpsn1995@gmail.com");
		mail.setSubject("Coupons and promos");
		mail.setText("Here are the exciting coupons and promos!!!!!!!!" + list.toString());
		javaMailSender.send(mail);
	}
	public Optional<Merchant> getMerchant(int id) {
		return mrepo.findById(id);
	}
}
