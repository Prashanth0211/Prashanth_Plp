package com.cg.spring.bean;

public class Coupons {
	
	private String coupon;
	private String promos;
	public Coupons() {
	}
	public Coupons(String coupon, String promos) {
		super();
		this.coupon = coupon;
		this.promos = promos;
	}
	public String getCoupon() {
		return coupon;
	}
	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}
	public String getPromos() {
		return promos;
	}
	public void setPromos(String promos) {
		this.promos = promos;
	}
	
}
