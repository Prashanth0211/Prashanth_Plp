package com.cg.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailfeappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailfeappApplication.class, args);
	}
}
