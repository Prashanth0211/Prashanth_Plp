package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Merchant;

@RestController
public class FrontEndController {
	@RequestMapping("/customers")
	public ModelAndView showCustomers() {
		RestTemplate rt = new RestTemplate();
		List<Customer> list = rt.getForObject("http://localhost:9191/showcustomers", ArrayList.class);
		return new ModelAndView("display", "cust", list);
	}
	@RequestMapping("/merchants")
	public ModelAndView showMerchants() {
		RestTemplate rt = new RestTemplate();
		List<Merchant> list = rt.getForObject("http://localhost:9191/showmerchants", ArrayList.class);
		return new ModelAndView("display1", "mer", list);
	}
}
