package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.Coupons;
import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Merchant;
import com.cg.spring.repo.ICouponsRepo;
import com.cg.spring.repo.ICustomerRepo;
import com.cg.spring.repo.IMerchantRepo;

@Service
public class CustomerServiceImpl implements ICustomerService{

	private JavaMailSender javaMailSender;
	@Autowired
	private ICustomerRepo repo;
	@Autowired
	private ICouponsRepo crepo;
	@Autowired
	private IMerchantRepo mrepo;
	
	
	public CustomerServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender=javaMailSender;
	}

	@Override
	public void NotificationCustomer(Optional<Customer> customer) throws MailException {
		Iterable<Coupons> list = crepo.findAll();
		System.out.println(list.toString());
		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(customer.get().getEmail());
		mail.setFrom("prashanthpsn1995@gmail.com");
		mail.setSubject("Coupons and promos");
		mail.setText("Here are the exciting coupons and promos!!!!!!!!" + list.toString());
		javaMailSender.send(mail);
	}
	@Override
	public List<Customer> showAllCustomers() {
		List<Customer> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}
	@Override
	public Optional<Customer> getCustomer(int id) {
		
		return repo.findById(id);
	}

	@Override
	public void NotificationMerchant(Optional<Merchant> merchant) throws MailException {
		Iterable<Coupons> list = crepo.findAll();
		System.out.println(list.toString());
		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(merchant.get().getEmail());
		mail.setFrom("prashanthpsn1995@gmail.com");
		mail.setSubject("Coupons and promos");
		mail.setText("Here are the exciting coupons and promos!!!!!!!!" + list.toString());
		javaMailSender.send(mail);
		
	}

	@Override
	public List<Merchant> showAllMerchants() {
		
		List<Merchant> list = new ArrayList<>();
		mrepo.findAll().forEach(list::add);
		return list;
	}

	@Override
	public Optional<Merchant> getMerchant(int id) {
		
		return mrepo.findById(id);
	}

	

}
