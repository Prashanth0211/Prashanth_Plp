package com.cg.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.mail.MailException;

import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Merchant;

public interface ICustomerService {
	public void NotificationCustomer(Optional<Customer> customer) throws MailException;

	public List<Customer> showAllCustomers();

	public Optional<Customer> getCustomer(int id);

	public void NotificationMerchant(Optional<Merchant> merchant) throws MailException;

	public List<Merchant> showAllMerchants();

	public Optional<Merchant> getMerchant(int id);
}
